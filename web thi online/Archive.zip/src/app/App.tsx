import { RouterProvider } from 'react-router';
import { router } from './routes';
import { Toaster } from 'sonner';
import AuthProvider from './providers/AuthProvider';

export default function App() {
  return (
    <AuthProvider>
      <RouterProvider router={router} />
      <Toaster position="top-right" richColors />
    </AuthProvider>
  );
}